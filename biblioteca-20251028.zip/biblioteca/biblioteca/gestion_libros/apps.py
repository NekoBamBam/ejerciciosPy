from django.apps import AppConfig


class GestionLibrosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gestion_libros'
