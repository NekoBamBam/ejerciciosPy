from django.apps import AppConfig


class GestionSociosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gestion_socios'
